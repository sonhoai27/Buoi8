let express = require('express');
let router = express.Router();
let parser = require('body-parser').urlencoded({extended: false});

let {mangTin, Tin} = require('../Tin.js');

router.get('/show', (req, res) => res.render('index', {
    username: 'KhoaPham',
    mangTin: mangTin}));
router.post('/show', parser, (req, res) => {
  res.send(req.body);
});

module.exports = router;
