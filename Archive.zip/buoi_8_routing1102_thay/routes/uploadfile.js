let express = require('express');
let router = express.Router();
let parser = require('body-parser').urlencoded({extended: false});

router.get('/show/upload', (req, res) => res.render('upload'));
// router.post('/show/upload', parser, (req, res) => {
//   res.send(req.body);
// });

let storage = require('../controllers/storage')
let upload = require('../controllers/upload')

router.post('/upload', (req, res)=>{
  upload(req, res, err=>{
    if(err) return res.send(err + '') //phai chuyen ve string
    res.send("Entered router")
  })
})

module.exports = router;