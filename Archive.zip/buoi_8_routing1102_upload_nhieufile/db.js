let pg = require('pg');

let config = {
  user: 'postgres',
  database: 'NODE1102',
  password: 'sontungmtp27',
  host: 'localhost',
  port: 5432,
  max: 2,
  idleTimeoutMillis: 1000,
}

let pool = new pg.Pool(config);

// pool.connect((err, client, done) => {
//     if(err) return console.log(err + '');
//     client.query('SELECT * FROM "News"', (err, result) => {
//         done(err);
//         if(err) return console.log(err + '');
//         console.log(result.rows);
//     });
// })

//truyen cb callback vao de dung vs xu ly bat dong bo, neu dung return thi se thuc thi ngang nhau, lenh truoc ko nhat thiet la c=xong truoc.
function queryDB(sql, cb) {
  pool.connect((err, client, done) => {
      if(err) return cb(err + '');
      // if(err) return console.log(err + '');
      //neu log thi no se dung ngay tai do hoai.. nen dung cb de rend ve ng dung
      client.query(sql, (err, result) => {
          done(err);
          if(err) return cb(err + '');
          cb(undefined ,result.rows);
      });
  })
}

module.exports = queryDB;
